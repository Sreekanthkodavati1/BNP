﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BnPBaseFramework.Reporting.Utils
{
    public class StringHelper
    {
        private static Object obj;

        public static int countNumberOfOccurencesInString(String toVerifyOccurences, String acutalString)
        {
            return 0;// StringUtils.countMatches(acutalString.Trim(), toVerifyOccurences);
        }

        public static bool verifyStringContainsByTrimmingValues(String actualString, String toVerify)
        {
            if (actualString.Trim().Contains(toVerify.Trim()))
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        public static bool verifyBothStringMatches(String actualString, String toVerify)
        {
            if (actualString.Equals(toVerify))
            {
                return true;
            }
            else
            {
                return false;
            }

        }
    }
}
