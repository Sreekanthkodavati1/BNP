﻿using BnPBaseFramework.Reporting.Base;
using BnPBaseFramework.Web;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BnPBaseFramework.Reporting.Utils
{
   public class TestStepHelper
    {
        public static TestStep StartTestStep(TestStep testStep)
        {
            testStep = new TestStep();
            testStep.setStepStartTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff", new CultureInfo("en-US")));

            return testStep;
        }

        public static TestStep EndTestStep(TestStep testStep, String testStepName, bool status, DriverContext driverContext)
        {
            testStep.setStepEndTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff", new CultureInfo("en-US")));
            testStep.setTestStep(testStepName);
            testStep.setStatus(status);
            //if (ConfigurationProvider.getConfiguration().isTakeScreenshot())
            //{
                testStep.setImageContent(driverContext.TakeScreenshot().ToString());
            //Console.WriteLine("testStep.getImageContent()"+testStep.getImageContent());
            //    //testStep.setImageContent(((TakesScreenshot)(driver)).getScreenshotAs(OutputType.BASE64));
            //}

            return testStep;
        }
    }
}
