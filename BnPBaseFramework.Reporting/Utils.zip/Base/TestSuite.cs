﻿using System;
using System.Collections.Generic;


namespace BnPBaseFramework.Reporting.Base
{
   public class TestSuite
    {
        private String suiteName;

        private String suiteStartTime;

        private String suiteEndTime;

        private String environment;

        private String SUT_Host;

        private int totalTestCasesExecuted;

        private int passed;

        private int failed;

        private List<TestCase> listOfTestCases;

        private String jenkinsBuildURL;

        private String id;

        public TestSuite() 
        {
            this.setId(Guid.NewGuid().ToString());
        }

        public String getSuiteName()
        {
            return this.suiteName;
        }

        public void setSuiteName(String suiteName)
        {
            this.suiteName = suiteName;
        }

        public String getEnvironment()
        {
            return this.environment;
        }

        public void setEnvironment(String environment)
        {
            this.environment = environment;
        }

        public String getSUT_Host()
        {
            return this.SUT_Host;
        }

        public void setSUT_Host(String sUT_Host)
        {
            this.SUT_Host = sUT_Host;
        }

        public int getPassed()
        {
            return this.passed;
        }

        public void setPassed(int passed)
        {
            this.passed = passed;
        }

        public int getFailed()
        {
            return this.failed;
        }

        public void setFailed(int failed)
        {
            this.failed = failed;
        }

        public List<TestCase> getListOfTestCases()
        {
            return this.listOfTestCases;
        }

        public void setListOfTestCases(List<TestCase> listOfTestCases)
        {
            this.listOfTestCases = listOfTestCases;
        }

        public int getTotalTestCasesExecuted()
        {
            return this.totalTestCasesExecuted;
        }

        public void setTotalTestCasesExecuted(int totalTestCasesExecuted)
        {
            this.totalTestCasesExecuted = totalTestCasesExecuted;
        }

        public String getJenkinsBuildURL()
        {
            return this.jenkinsBuildURL;
        }

        public void setJenkinsBuildURL(String jenkinsBuildURL)
        {
            this.jenkinsBuildURL = jenkinsBuildURL;
        }

        public String getSuiteStartTime()
        {
            return this.suiteStartTime;
        }

        public void setSuiteStartTime(String suiteStartTime)
        {
            this.suiteStartTime = suiteStartTime;
        }

        public String getSuiteEndTime()
        {
            return this.suiteEndTime;
        }

        public void setSuiteEndTime(String suiteEndTime)
        {
            this.suiteEndTime = suiteEndTime;
        }

        public String getId()
        {
            return this.id;
        }

        public void setId(String id)
        {
            this.id = id;
        }
    }
}
