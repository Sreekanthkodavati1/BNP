﻿using BnPBaseFramework.Reporting.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BnPBaseFramework.Reporting.Utils
{
   public class DBUtils
    {
       // public static bool storeRecordsToDB(String suiteName, TestSuite testSuite, GlobalVariables globalVariables)
        public static bool storeRecordsToDB(String suiteName, TestSuite testSuite)

        {
            bool status;
            try
            {
                status = true;
            }
            catch (Exception e)
            {
                //  Fail to load to Mongo, Write to File so that re import can happen
                status = false;
                //e.StackTrace;
            }

            return status;
        }
    }
}
