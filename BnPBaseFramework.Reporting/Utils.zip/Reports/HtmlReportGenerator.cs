﻿using BnPBaseFramework.Reporting.Base;
using BnPBaseFramework.Web;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BnPBaseFramework.Reporting.Reports
{
    public class HtmlReportGenerator
    {
        //public String generateHTMLReport(TestSuite testSuite, Dictionary<String, String> listOfTestCasesReference)
        public String generateHTMLReport(TestSuite testSuite)
        {
            try
            {
                String currentDirectoryPath = AppDomain.CurrentDomain.BaseDirectory;
                String testSuiteStartTemplateBuffer = TemplatesForHtmlReport.getTestSuiteStartTemplate();
                String testSuiteEndTemplateBuffer = TemplatesForHtmlReport.getTestSuiteEndTemplate();
                // String healthCheckData = TemplatesForHtmlReport.getHealthCheckDataTemplate();
                String workspaceRef = "";
                // RallyRestApi restApi = null;
                String testCaseDetailsURL = "";
                String allTestSuiteHtml = this.buildTestSuite(testSuiteStartTemplateBuffer.ToString(), testSuite);
                //String allTestCasesHtml = this.buildTestCasesAndTestSteps(currentDirectoryPath, testSuite, workspaceRef, listOfTestCasesReference);
                String testSuiteEnd = testSuiteEndTemplateBuffer.ToString();
                testSuiteEnd = testSuiteEnd.Replace("<%=PassedTestCases%>", testSuite.getPassed().ToString());
                testSuiteEnd = testSuiteEnd.Replace("<%=FailedTestCases%>", testSuite.getFailed().ToString());
               // allTestSuiteHtml = allTestSuiteHtml + allTestCasesHtml;
                //allTestSuiteHtml = (allTestSuiteHtml + healthCheckData.ToString().Replace("<%=HealthCheckData%>", ("<b>Application Software Versions:</b> \n"
                //                + (globalVariables.getHealthCheck_Software() + ("\r\n <b>Back Of House</b>\n"
                //                + (globalVariables.getHealthCheck_BOH() + ("\r\n <b>Point Of Sale</b>\n" + globalVariables.getHealthCheck_POS())))))));
                allTestSuiteHtml = allTestSuiteHtml + testSuiteEnd;
                return allTestSuiteHtml;
            }
            catch (IOException e)
            {
                throw new Exception(("Not able to generate HTML report due to " + e.Message));
            }

        }

        //private StringBuilder readJSTemplateFile(String filePath)
        //{
        //    try
        //    {
        //        String line = "";
        //        FileReader fileReader = new FileReader(new File(filePath));
        //        BufferedReader bufferedReader = new BufferedReader(fileReader);
        //        StringBuilder templateBuffer = new StringBuilder();
        //        while ((bufferedReader.readLine() != null))
        //        {
        //            templateBuffer.Append(line);
        //        }

        //        bufferedReader.close();
        //        return templateBuffer;
        //    }
        //    catch (IOException e)
        //    {
        //        throw new Exception(("Not able to read Template File "
        //                        + (filePath + (" due to " + e.getMessage()))));
        //    }

        //}

        private String buildTestSuite(String allTestSuiteHtml, TestSuite testSuite)
        {
            allTestSuiteHtml = allTestSuiteHtml.Replace("<%=PassedTestCases%>", testSuite.getPassed().ToString());
            allTestSuiteHtml = allTestSuiteHtml.Replace("<%=FailedTestCases%>", testSuite.getFailed().ToString());
            allTestSuiteHtml = allTestSuiteHtml.Replace("<%=Suite_Name%>", testSuite.getSuiteName());
            allTestSuiteHtml = allTestSuiteHtml.Replace("<%=Suite_StartTime%>", testSuite.getSuiteStartTime());
            allTestSuiteHtml = allTestSuiteHtml.Replace("<%=Suite_EndTime%>", testSuite.getSuiteEndTime());
            allTestSuiteHtml = allTestSuiteHtml.Replace("<%=SUT_HOST%>", "Prod");
            allTestSuiteHtml = allTestSuiteHtml.Replace("<%=EnvironmentTested%>", testSuite.getEnvironment());
            //if ((globalVariables.getGM_Version() != null))
            //{
            //    allTestSuiteHtml = allTestSuiteHtml.Replace("<%=GM_Version%>", "Prod");
            //}
            //else
            //{
            //    allTestSuiteHtml = allTestSuiteHtml.Replace("<%=GM_Version%>", "");
            //}

            //if ((globalVariables.getSUS_Version() != null))
            //{
            //    allTestSuiteHtml = allTestSuiteHtml.Replace("<%=GM_SUS_Version%>", globalVariables.getSUS_Version());
            //}
            //else
            //{
            //    allTestSuiteHtml = allTestSuiteHtml.Replace("<%=GM_SUS_Version%>", "");
            //}

            //if ((globalVariables.getFMS_Version() != null))
            //{
            //    allTestSuiteHtml = allTestSuiteHtml.Replace("<%=GM_FMS_Version%>", globalVariables.getFMS_Version());
            //}
            //else
            //{
            //    allTestSuiteHtml = allTestSuiteHtml.Replace("<%=GM_FMS_Version%>", "");
            //}

            allTestSuiteHtml = allTestSuiteHtml.Replace("<%=Screen_Shots%>", "true");
            return allTestSuiteHtml;
        }

        //private String buildTestCasesAndTestSteps(String currentDirectoryPath, TestSuite testSuite, String workspaceRef, Dictionary<String, String> listOfTestCasesReference)
        //{
        //    String testCaseStartTemplateBuffer = TemplatesForHtmlReport.getTestCaseStartTemplate();
        //    String testCaseEndTemplateBuffer = TemplatesForHtmlReport.getTestCaseEndTemplate();
        //    String testStepTemplateBuffer = TemplatesForHtmlReport.getTestStepTemplate();
        //    String screenShotsTemplateStart = TemplatesForHtmlReport.getScreenShotsTemplate();
        //    String allTestCasesHtml = "";
        //    for (int testCaseIndex = 0; (testCaseIndex < testSuite.getListOfTestCases().Count); testCaseIndex++)
        //    {
        //        TestCase testCase = testSuite.getListOfTestCases().get(testCaseIndex);
        //        String testCaseUniqueString = Guid.NewGuid().ToString();
        //        String testCaseStartHtml = testCaseStartTemplateBuffer.ToString();
        //        testCaseStartHtml = testCaseStartHtml.Replace("<%=Test_Case_Number%>", testCaseUniqueString);
        //        if ((testCase.getTestCaseName().Length >= 35))
        //        {
        //            testCaseStartHtml = testCaseStartHtml.Replace("<%=Test_Case_Name%>", (Matcher.quoteReplacement(testCase.getTestCaseName().substring(0, 35)) + " ....."));
        //        }
        //        else
        //        {
        //            testCaseStartHtml = testCaseStartHtml.Replace("<%=Test_Case_Name%>", Matcher.quoteReplacement(testCase.getTestCaseName()));
        //        }

        //        String[] testCases = testCase.getTestCaseName().Split(' ');
        //        String reference = "";
        //        String testCaseId = "";
        //        if ((listOfTestCasesReference.get(testCases[0]) == null))
        //        {
        //            //if (ConfigurationProvider.getConfiguration().getEnvironment().equals("prod"))
        //            //{
        //            //    if ((testCases[0].startsWith("TC")
        //            //                && !testCases[0].equals("TC")))
        //            //    {

        //            //    }

        //            //}

        //        }
        //        else
        //        {
        //            reference = listOfTestCasesReference.get(testCases[0]);
        //            testCaseId = reference.Substring((reference.IndexOf("/testcase/") + 10), reference.Length);
        //        }

        //        if (testCaseId.isEmpty())
        //        {
        //            testCaseStartHtml = testCaseStartHtml.Replace("<%=Test_Case_Name_Afer_Expansion%>", Matcher.quoteReplacement(testCase.getTestCaseName()));
        //        }
        //        else
        //        {
        //            testCaseStartHtml = testCaseStartHtml.Replace("<%=Test_Case_Name_Afer_Expansion%>", ("<a target=\\\"_blank\\\" href=\\\""
        //                            + (testCaseDetailsURL
        //                            + (testCaseId + ("\\\">"
        //                            + (Match.quoteReplacement(testCase.getTestCaseName()) + "</a>"))))));
        //        }

        //        if (testCase.isStatus())
        //        {
        //            testCaseStartHtml = testCaseStartHtml.Replace(" <span class=\\\"label label-danger\\\" title=\\\"Failed\\\">Failed</span>", "");
        //        }
        //        else
        //        {
        //            testCaseStartHtml = testCaseStartHtml.Replace("<span class=\\\"label label-success\\\" title=\\\"Passed\\\">Passed</span>", "");
        //        }

        //        if ((testCase.getErrorMessage() != null))
        //        {
        //            testCaseStartHtml = testCaseStartHtml.Replace("<%=ErrorMessage%>", ("<b>Error Message : </b>"
        //                            + (Matcher.quoteReplacement(testCase.getErrorMessage()) + ")")));
        //        }
        //        else
        //        {
        //            testCaseStartHtml = testCaseStartHtml.Replace("<%=ErrorMessage%>", "");
        //        }

        //        if ((testCase.getImageContent() != null))
        //        {
        //            testCaseStartHtml = testCaseStartHtml.replace("<%=ScreenShot%>", ("<a class=\\\"screenshot\\\" href=\\\"data:image/png;base64,"
        //                            + (Matcher.quoteReplacement(testCase.getImageContent()) + ("\\\">\n" + ("                                        <img class=\\\"screenshot\\\" style=\\\"height:100%;width:100%\\\" id" +
        //                            "=\\\"my_images\\\" src=\\\"data:image/png;base64,"
        //                            + (Matcher.quoteReplacement(testCase.getImageContent()) + ("\\\">\n" + "                                    </a>")))))));
        //        }
        //        else
        //        {
        //            testCaseStartHtml = testCaseStartHtml.Replace("<%=ScreenShot%>", "");
        //        }

        //        int passCount = 0;
        //        int failCount = 0;
        //        if ((testCase.getTestCaseSteps() != null))
        //        {
        //            for (int totalTestSteps = 0; (totalTestSteps < testCase.getTestCaseSteps().size()); totalTestSteps++)
        //            {
        //                if (testCase.getTestCaseSteps().get(totalTestSteps).isStatus())
        //                {
        //                    passCount++;
        //                }
        //                else
        //                {
        //                    failCount++;
        //                }

        //            }

        //        }

        //        testCaseStartHtml = testCaseStartHtml.Replace("<%=Total_Test_Steps_Successful%>", Integer.ToString(passCount));
        //        testCaseStartHtml = testCaseStartHtml.Replace("<%=Total_Test_Steps_Fail%>", Integer.ToString(failCount));
        //        testCaseStartHtml = testCaseStartHtml.Replace("<%=Test_Case_Start%>", dateFormat.format(testCase.getStartTime()));
        //        testCaseStartHtml = testCaseStartHtml.Replace("<%=Test_Case_End%>", dateFormat.format(testCase.getEndTime()));
        //        testCaseStartHtml = testCaseStartHtml.Replace("<%=Test_Case_Status%>", Boolean.ToString(testCase.isStatus()));
        //        String allTestStepsHtml = "";
        //        if ((testCase.getTestCaseSteps() != null))
        //        {
        //            for (int testStepIndex = 0; (testStepIndex < testCase.getTestCaseSteps().size()); testStepIndex++)
        //            {
        //                String testStepUniqueString = UUID.randomUUID().ToString();
        //                String testStepHtml = testStepTemplateBuffer.ToString();
        //                TestStep testStep = testCase.getTestCaseSteps().get(testStepIndex);
        //                testStepHtml = testStepHtml.Replace("<%=StepNumber%>", testStepUniqueString);
        //                testStepHtml = testStepHtml.replace("<%=Test_Step_Name%>", Matcher.quoteReplacement(testStep.getTestStep().Replace(";", "</br>")));
        //                if (testStep.isStatus())
        //                {
        //                    testStepHtml = testStepHtml.replace(" <span class=\\\"label label-danger\\\" title=\\\"Failed\\\">Failed</span>", "");
        //                }
        //                else
        //                {
        //                    testStepHtml = testStepHtml.replace("<span class=\\\"label label-success\\\" title=\\\"Passed\\\">Passed</span>", "");
        //                }

        //                testStepHtml = testStepHtml.replace("<%=Step_Start_Time%>", dateFormat.format(testStep.getStepStartTime()));
        //                testStepHtml = testStepHtml.replace("<%=Step_End_Time%>", dateFormat.format(testStep.getStepEndTime()));
        //                if ((testStep.getInput() != null))
        //                {
        //                    testStepHtml = testStepHtml.replace("<%=Step_Input>", Matcher.quoteReplacement(testStep.getInput().Replace(";", "</br>")));
        //                }
        //                else
        //                {
        //                    testStepHtml = testStepHtml.replace("<%=Step_Input>", "");
        //                }

        //                if ((testStep.getOutput() != null))
        //                {
        //                    testStepHtml = testStepHtml.replace("<%=Step_Output>", Matcher.quoteReplacement(testStep.getOutput()));
        //                }
        //                else
        //                {
        //                    testStepHtml = testStepHtml.replace("<%=Step_Output>", "");
        //                }

        //                if ((testStep.getExpectedResult() != null))
        //                {
        //                    testStepHtml = testStepHtml.replace("<%=Step_Expected_Result%>", Matcher.quoteReplacement(testStep.getExpectedResult()));
        //                }
        //                else
        //                {
        //                    testStepHtml = testStepHtml.replace("<%=Step_Expected_Result%>", "");
        //                }

        //                testStepHtml = testStepHtml.replace("<%=Step_Status%>", Boolean.ToString(testStep.isStatus()));
        //                if (((testStep.getImageContent() != null)
        //                            && (testStep.getImageContent().length() > 20)))
        //                {
        //                    testStepHtml = testStepHtml.replace("<%=ScreenShot%>", ("<a class=\\\"screenshot\\\" href=\\\"data:image/png;base64,"
        //                                    + (Matcher.quoteReplacement(testStep.getImageContent()) + ("\\\">\n" + ("                                        <img class=\\\"screenshot\\\" style=\\\"height:100%;width:100%\\\" id" +
        //                                    "=\\\"my_images\\\" src=\\\"data:image/png;base64,"
        //                                    + (Matcher.quoteReplacement(testStep.getImageContent()) + ("\\\">\n" + "                                    </a>")))))));
        //                }
        //                else
        //                {
        //                    testStepHtml = testStepHtml.replace("<%=ScreenShot%>", "");
        //                }

        //                allTestStepsHtml = (allTestStepsHtml + testStepHtml);
        //                if (((testStep.getImages() != null)
        //                            && (testStep.getImages().size() > 0)))
        //                {
        //                    String screenShotUniqueString = UUID.randomUUID().ToString();
        //                    String screenShotString = screenShotsTemplateStart.ToString();
        //                    screenShotString = screenShotString.Replace("<%=ScreenShotNumber%>", screenShotUniqueString);
        //                    int imageCountIndex = 1;
        //                    foreach (String imageContent in testStep.getImages())
        //                    {
        //                        screenShotString = (screenShotString + ("<b>Screenshot-"
        //                                    + (imageCountIndex + "</b>")));
        //                        screenShotString = (screenShotString + ("<a class=\\\"screenshot\\\" href=\\\"data:image/png;base64,"
        //                                    + (Matcher.quoteReplacement(imageContent) + ("\\\">\n" + ("                                        <img class=\\\"screenshot\\\" style=\\\"height:100%;width:100%\\\" id" +
        //                                    "=\\\"my_images\\\" src=\\\"data:image/png;base64,"
        //                                    + (Matcher.quoteReplacement(imageContent) + ("\\\">\n" + "                                    </a>")))))));
        //                        imageCountIndex++;
        //                    }

        //                    allTestStepsHtml = (allTestStepsHtml + screenShotString);
        //                    allTestStepsHtml += "</div></div></div></div>";
        //                }

        //            }

        //        }

        //        if (((testCase.getImages() != null)
        //                    && (testCase.getImages().size() > 0)))
        //        {
        //            String screenShotUniqueString = UUID.randomUUID().ToString();
        //            String screenShotString = screenShotsTemplateStart.ToString();
        //            screenShotString = screenShotString.Replace("<%=ScreenShotNumber%>", screenShotUniqueString);
        //            int imageCountIndex = 1;
        //            foreach (String imageContent in testCase.getImages())
        //            {
        //                screenShotString = (screenShotString + ("<b>Screenshot-"
        //                            + (imageCountIndex + "</b>")));
        //                screenShotString = (screenShotString + ("<a class=\\\"screenshot\\\" href=\\\"data:image/png;base64,"
        //                            + (Matcher.quoteReplacement(imageContent) + ("\\\">\n" + ("                                        <img class=\\\"screenshot\\\" style=\\\"height:100%;width:100%\\\" id" +
        //                            "=\\\"my_images\\\" src=\\\"data:image/png;base64,"
        //                            + (Matcher.quoteReplacement(imageContent) + ("\\\">\n" + "                                    </a>")))))));
        //                imageCountIndex++;
        //            }

        //            allTestStepsHtml = (allTestStepsHtml + screenShotString);
        //            allTestStepsHtml += "</div></div></div></div>";
        //        }

        //        testCaseStartHtml = (testCaseStartHtml + allTestStepsHtml);
        //        testCaseStartHtml = (testCaseStartHtml + testCaseEndTemplateBuffer.ToString());
        //        allTestCasesHtml = (allTestCasesHtml + testCaseStartHtml);
        //    }

        //    return allTestCasesHtml;
        //}
    }
}
