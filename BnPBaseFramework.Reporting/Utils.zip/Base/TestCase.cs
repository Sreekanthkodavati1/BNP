﻿using System;
using System.Collections.Generic;
using System.Globalization;

namespace BnPBaseFramework.Reporting.Base
{
    public class TestCase
    {
        private String startTime;

        private String endTime;

        private String testCaseName;

        private bool status;

        private List<TestStep> testCaseSteps;

        private String errorMessage;

        private String imageContent;

        private List<String> images;

        private String id;

        private String testSuiteId;

        public TestCase()               
        {
            this.setId(Guid.NewGuid().ToString());
        }

        public TestCase(String testCaseName) 
        {
            this.setId(Guid.NewGuid().ToString());
            this.setStartTime(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff", new CultureInfo("en-US")));
            this.setTestCaseName(testCaseName);
        }

        public List<String> getImages()
        {
            return this.images;
        }

        public void setImages(List<String> images)
        {
            this.images = images;
        }

        public String getStartTime()
        {
            return this.startTime;
        }

        public void setStartTime(String startTime)
        {
            this.startTime = startTime;
        }

        public String getEndTime()
        {
            return this.endTime;
        }

        public void setEndTime(String endTime)
        {
            this.endTime = endTime;
        }

        public String getTestCaseName()
        {
            return this.testCaseName;
        }

        public void setTestCaseName(String testCaseName)
        {
            this.testCaseName = testCaseName;
        }

        public List<TestStep> getTestCaseSteps()
        {
            return this.testCaseSteps;
        }

        public void setTestCaseSteps(List<TestStep> testCaseSteps)
        {
            this.testCaseSteps = testCaseSteps;
        }

        public bool isStatus()
        {
            return this.status;
        }

        public void setStatus(bool status)
        {
            this.status = status;
        }

        public String getErrorMessage()
        {
            return this.errorMessage;
        }

        public void setErrorMessage(String errorMessage)
        {
            this.errorMessage = errorMessage;
        }

        public String getImageContent()
        {
            return this.imageContent;
        }

        public void setImageContent(String imageContent)
        {
            this.imageContent = imageContent;
        }

        public String getId()
        {
            return this.id;
        }

        public void setId(String id)
        {
            this.id = id;
        }

        public void setTestSuiteId(String testSuiteId)
        {
            this.testSuiteId = testSuiteId;
        }
    }
}
