﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BnPBaseFramework.Reporting.Base
{
    public class TestStep
    {
        private String testStep;

        private bool status;

        private String input;

        private String output;

        private String expectedResult;

        private String stepStartTime;

        private String stepEndTime;

        private String errorMessage;

        private String imageContent;

        private List<String> images;

        public String getTestStep()
        {
            return this.testStep;
        }

        public void setTestStep(String testStep)
        {
            this.testStep = testStep;
        }

        public bool isStatus()
        {
            return this.status;
        }

        public void setStatus(bool status)
        {
            this.status = status;
        }
        
        public String getInput()
        {
            return this.input;
        }

        public void setInput(String input)
        {
            this.input = input;
        }

        public String getOutput()
        {
            return this.output;
        }

        public void setOutput(String output)
        {
            this.output = output;
        }

        public String getExpectedResult()
        {
            return this.expectedResult;
        }

        public void setExpectedResult(String expectedResult)
        {
            this.expectedResult = expectedResult;
        }

        public void setErrorMessage(String errorMessage)
        {
            this.errorMessage = errorMessage;
        }

        public String getImageContent()
        {
            return this.imageContent;
        }

        public void setImageContent(String imageContent)
        {
            this.imageContent = imageContent;
        }

        public List<String> getImages()
        {
            return this.images;
        }

        public void setImages(List<String> images)
        {
            this.images = images;
        }

        public String getStepStartTime()
        {
            return this.stepStartTime;
        }

        public void setStepStartTime(String stepStartTime)
        {
            this.stepStartTime = stepStartTime;
        }

        public String getStepEndTime()
        {
            return this.stepEndTime;
        }

        public void setStepEndTime(String stepEndTime)
        {
            this.stepEndTime = stepEndTime;
        }
    }
}
